package AppiumTest.AppiumTest;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import AppiumTest.Pages.AndroidHomePage;
 
public class App extends LeafTapsWrappers{
	
		private static AndroidDriver driver;
		@BeforeTest
		public void setup(String[] args) throws Exception {
			
			// Passing the information to the appium
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
			capabilities.setCapability("deviceName", "Micromax A311");
			capabilities.setCapability("platformVersion", "4.4.2");
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("app", app.getAbsolutePath());
			capabilities.setCapability("appPackage", "in.ebay.mShop.android.shopping");
			capabilities.setCapability("appActivity", "com.ebay.mShop.home.HomeActivity");
			
			//Creating the driver object
			driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			Thread.sleep(5000);
		}	
		
		@BeforeClass
		public void testDetails(){
			testCaseName = "EbayPurchase_Order";
			testDescription = "Book an order in ebay";
			category = "Smoke";
			authors = "Prasanth";
			dataSheetName = "AndroidPOCTestData";
		}
		
		// Data provider to fetch data from the external source
		@Test(dataProvider="fetchData")
		public void orderPurchase(String LoginId,String pwd, String CardNumber , String month , String year , String cvv , String zip){
			new AndroidHomePage(driver, test);
			AndroidHomePage.ebayLogin(driver,LoginId,pwd);
			AndroidHomePage.searchForItem(driver,item);
			AndroidHomePage.addToCart(driver);
			AndroidHomePage.purchase(driver,CardNumber,month,year,cvv,zip);
		}		
	}
 
}
