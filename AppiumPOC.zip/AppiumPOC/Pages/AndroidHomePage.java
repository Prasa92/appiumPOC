package AppiumTest.Pages;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.TouchAction;
import wrappers.LeafTapsWrappers;


public class AndroidHomePage extends LeafTapsWrappers {

    /** Verify the home page has loaded **/
	public AndroidHomePage(RemoteWebDriver driver,ExtentTest test){	
		 this.driver = driver;
		 this.test = test;
		if(!verifyTitle("eBay.in")){
			reportStep("This is not HomePage Page", "FAIL");
		}	
	}
	
	//Ebay Page Objects
	private static By txt_username= By.xpath("//*[@name='userid']");
	private static By txt_password= By.xpath("//*[@name='pass']");
	private static By btn_Login= By.xpath("//*[@id='//*[@id='sgnBt']']");
	private static By SearchanItem= By.xpath("//*[@class='search-bar-text' and contains(text(),'looking')]");
	private static By ClickSearchBtn= By.xpath("(//*[text()='search on ebay'])[2]");
	private static By AddtoCart= By.xpath("//*[@id='btnCart' and .='Add to Cart']");
	private static By ProceedtoPay= By.xpath("//*[@id='proceedToPay']");
	private static By txt_Select_Payment_Method = By.xpath("//*[@label=\"Select a payment method.\"]");
	private static By txt_Payment_Credit_Card = By.xpath("//*[@label=\"Credit or debit card\"]");
	private static By txt_bx_Enter_Card_Number = By.xpath("//*[contains(@label,\"Card number\")]");
	private static By txt_dd_Card_Month = By.xpath("//*[contains(@label,\"MM picker item\")]");
	private static By txt_dd_Card_Year = By.xpath("//*[contains(@label,\"YYYY picker item\")]");
	private static By txt_bx_CVC_Number = By.xpath("//*[contains(@label,\"CVC regular\")]");
	private static By txt_bx_Card_Zip = By.xpath("//*[contains(@label,\"Card ZIP Code regular\")]");
	private static By btn_apply = By.xpath("//*[@class='input-group-btn']/button[.='Apply']");
	
	/*
	* Method used for Logging into ebay
	* @ paramaters - user name , password
	*/
	public static void ebayLogin(AndroidDriver<WebElement> driver , String Uname , String Password) throws Exception {
		enterByXpath(txt_username,Uname);
		enterByXpath(txt_password,Password);
		clickByXpath(btn_Login);
		
		//explicit wait to wait until the expected condition is met or not 
		WebDriverWait wait = new WebDriverWait(driver, 50);
		WebElement element = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//*[text()='Shop by Category']")));
		if(element.isDisplayed()) {
			reportStep("Home page is getting displayed", "Passed");
		}else {
			reportStep("Home page is not getting displayed", "Failed");
		}
	}
    
	/*
	* Method used for searching an item fom the serach list
	* @ paramaters - item
	*/
	public static void searchForItem(AndroidDriver<WebElement> driver , String item) throws Exception {	
		enterByXpath(SearchanItem,item);
		clickByXpath(ClickSearchBtn);
		WebDriverWait wait = new WebDriverWait(driver, 50);
		WebElement element = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//img[@itemprop='image']")));
		if(!element.isDisplayed()) {
			reportStep("The element with xpath: "+element+" could not be clicked.", "FAIL");
		}else {
			for (int i1 = 0; i1 < 7; i1++) {
				JavascriptExecutor js2 = driver;
				HashMap<String, String> scrollObject2 = new HashMap<String, String>();
				scrollObject2.put("direction", "up");
				js2.executeScript("mobile: swipe", scrollObject2);
				Thread.sleep(2000);
				reportStep("Item Clicked from the search results", "PASS");
			}
		}
	}
	
	/*
	* Method used for adding an element to the cart
	* @ paramaters - item
	*/
	public static void addToCart(AndroidDriver<WebElement> driver) throws Exception {
		//Tapping on x and y cordinates
		WebElement text = driver.findElement(AddtoCart);
		int radioX = text.getLocation().getX();
		int radioY = text.getLocation().getY();
		tapElement(radioX, radioY, driver);
	}
	
	/*
	* Method used for clicking on the element based upon the coordinates
	* 
	*/
	public static boolean tapElement(int x, int y, AndroidDriver<WebElement> driver) {
		try {
			new TouchAction(driver).tap(x, y).perform();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/*
	* Method used for placing an order
	* @params - Card Number , month , Year , CVV , Zip
	*/
	public static void purchase(AndroidDriver<WebElement> driver , String CardNumber , String month , String year , String cvv , String zip) throws Exception {
		//Tapping on x and y cordinates
		
		WebElement text = driver.findElement(ProceedtoPay);
		int radioX = text.getLocation().getX();
		int radioY = text.getLocation().getY();
		tapElement(radioX, radioY, driver);
		
		/*credit card number details
		 * @params - CardNumber 
		 */
		enterByXpath(txt_Payment_Credit_Card,CardNumber);
		
		/*credit card month details
		 * @params - month 
		 */
		selectVisibileTextByXPath(txt_dd_Card_Month,month);
		
		/*credit card year details
		 * @params - year 
		 */
		selectVisibileTextByXPath(txt_dd_Card_Month,year);
		
		/*credit card cvv details
		 * @params - cvv number 
		 */
		enterByXpath(txt_bx_CVC_Number,cvv);
		
		/*credit card cvv details
		 * @params - zip number 
		 */
		enterByXpath(txt_bx_Card_Zip,zip);
		
		//click  Apply Button
		clickByxpath(btn_apply);
		
	}
}
